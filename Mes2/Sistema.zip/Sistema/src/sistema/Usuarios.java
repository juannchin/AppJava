package sistema;

import java.util.ArrayList;

/**
 *
 * @author MCoreas
 */
public class Usuarios {
    private ArrayList correos;
    private ArrayList nombres;
    private ArrayList apellidos;
    private ArrayList claves;
    private ArrayList niveles;
    
    public Usuarios(){
        correos = new ArrayList();
        nombres = new ArrayList();
        apellidos = new ArrayList();
        claves = new ArrayList();
        niveles = new ArrayList();   
        int nivel = 1;
    
        for(int i=1; i<=10; i++){
            correos.add("CoreasDJ"+i+"@utec");
            nombres.add("Milagro" + i);
            apellidos.add("Coreas"+i);
            claves.add("clave"+i);
            niveles.add(nivel);
            nivel++;
            
            if(nivel == 4) nivel = 1;
        }
    }
    
    /**
     * DOCUMENTACION...
     * @param correos recibira el correo del usuario
     * @param nombres recibira el nombre del usuario
     * @param apellidos recibira el apellido del usuario
     * @param claves recibira la clave del usuario
     * @param niveles recibira el nivel del usuario
     */
    public void setUsuarios(String correos, String nombres, String apellidos,
            String claves, String niveles){
        
        this.correos.add(correos);
        this.nombres.add(nombres);
        this.apellidos.add(apellidos);
        this.claves.add(claves);
        this.niveles.add(niveles);
    }
    
    //Obteniendo la cantidad de correos en el array
    public int getCantCorreos(){
        return correos.size();
    }
    
    //Metodo para saber si el correo del login existe.
    /**
     * Este metodo se utiliza para determinar si existe un correo en el Array
     * correos. 
     * @param elCorreoBuscar parametro que recibe el correo a buscar en 
     * el array
     * @return retorna Verdadero si encuentra el dato buscado o
     * retorna Falso si NO encuentra el dato buscado
     */
    public boolean buscarCorreo(String elCorreoBuscar){
        //contains retorna Verdadero si encuentra el dato buscado
        //contains retorna Falso si NO encuentra el dato buscado
        return correos.contains(elCorreoBuscar);
    }
    
    //Metodo para saber si el correo del login existe.
    public int buscarCorreo2(String elCorreoBuscar){
        //indexOf retorna el indice del valor encontrado dentro del Array
        //indexOf retorna -1 en caso que no encuentre el valor buscado
        return correos.indexOf(elCorreoBuscar);
    }
    
    //Buscando el correo y la clave del usuario 
    public boolean login(String elUsuario, String laClave){
        int indCorreoEncontrado = buscarCorreo2(elUsuario);
        //haciendo uso del array
        int indClaveEncontrada = claves.indexOf(laClave);
        
        //validando el correo ingresado al login
        if(indCorreoEncontrado == indClaveEncontrada && indCorreoEncontrado != -1){
            return true;
        }else{
            return false;
        }
    }
    
    public String getCorreo(int indCorreo){
        return correos.get(indCorreo).toString();
    }
    
    public String getNombre(int indCorreo){
        return nombres.get(indCorreo).toString();
    }
    
    public String getApellido(int indCorreo){
        return apellidos.get(indCorreo).toString();
    }
    
    public String getClave(int indCorreo){
        return claves.get(indCorreo).toString();
    }
    
    public String getNivel(int indCorreo){
        return niveles.get(indCorreo).toString();
    }
    
    public void eliminarUsuario(int indiceCorreoEliminar){
        correos.remove(indiceCorreoEliminar);
        nombres.remove(indiceCorreoEliminar);
        apellidos.remove(indiceCorreoEliminar);
        claves.remove(indiceCorreoEliminar);
        niveles.remove(indiceCorreoEliminar);
    }
    
    public void editarClave(int indiceClave, String claveNueva){
        claves.set(indiceClave, claveNueva);
    }
    
    //
    public void editarNivel(int indice, String nivelNuevo){
        niveles.set(indice, nivelNuevo);
    }
    
    public void editarCorreo(int indice, String correoNuevo){
        correos.set(indice, correoNuevo);
    }
    
    public void editarNombres(int indice, String nombreNuevo){
        nombres.set(indice, nombreNuevo);
    }
    
    public void editarApellidos(int indice, String apellidoNuevo){
        apellidos.set(indice, apellidoNuevo);
    }
    
}
