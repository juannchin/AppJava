package sistema;

import java.util.Scanner;

/**
 *
 * @author MCoreas
 */
public class Sistema {
    /**
     * @param MDJes the command line arguments
     */
    public static void main(String[] MDJes) {
        // TODO code application logic here
        
        Scanner leer = new Scanner(System.in);
        Usuarios usuarios = new Usuarios();
        int respuesta = 1;
        int cont = 1;
        
        System.out.println("Cantidad de correos: "+usuarios.getCantCorreos());
        
        do{  
            System.out.print("Ingrese su usuario: ");
            String elUsuario = leer.nextLine();
            System.out.print("Ingrese su clave: ");
            String laClave = leer.nextLine();
            System.out.println("");

            boolean estadoLogin = false;

            estadoLogin = usuarios.login(elUsuario, laClave);
            int opcionesMenuPrincipal;
        
            if(estadoLogin){
                int indUsuario = usuarios.buscarCorreo2(elUsuario);
                String nombreDUsuario = usuarios.getCorreo(indUsuario);
                System.out.println("");
                System.out.println("◄◄ BIENVENIDO AL SISTEMA "+ nombreDUsuario +" ►►"); //alt +17 / alt+16
                do{
                    
                    /* 
                        Para las opciones de editar o eliminar cualquier dato menos contraseña 
                        no permitir editar los datos del usuario actual ingresado en el sistema
                    */
                    System.out.println("");
                    System.out.println("▓▓▓▓▓▓ MENU DE OPCIONES "+ nombreDUsuario +" ▓▓▓▓▓▓"); //alt+178
                    System.out.println("1- Listado de usuarios");
                    System.out.println("2- Agregar usuarios");
                    System.out.println("3- Buscar usuarios");
                    System.out.println("4- Eliminar usuarios");
                    System.out.println("5- Editar usuarios"); //HACER ESTA PARTE
                    /*
                        Para editar los datos del usuario mostrar el siguiente menu
                        1- editar correo
                        2- editar nombres
                        3- editar apellidos
                        4- cancelar -> Retornar al menu principal
                        Validar la entrada de las opciones del menu editar
                    */
                    System.out.println("6- Cambiar contaseña");
                    System.out.println("7- Cambiar nivel de usuario");
                    System.out.println("8- Listado de usuarios nivel de usuario");
                    System.out.println("9- Listado de usuarios nivel de asistente");
                    System.out.println("10- Listado de usuarios nivel de administrador");
                    System.out.println("11- Acerca de ...");
                    System.out.println("12- Cerrar Sesión");
                    System.out.println("13- Salir del Sistema");
                    System.out.println("");
                    System.out.print("Ingrese su opcion del menu: ");
                    opcionesMenuPrincipal = leer.nextInt();
                    leer.nextLine();

                    switch(opcionesMenuPrincipal){
                        case 1:
                            System.out.println("");
                            System.out.println("▓▓▓▓ LISTADO DE USUARIOS ▓▓▓▓");
                            int cantidadUsuarios = usuarios.getCantCorreos();

                            for(int i =0; i < cantidadUsuarios; i++){
                                System.out.println("Correo: "+usuarios.getCorreo(i));
                                System.out.println("Nombres: "+usuarios.getNombre(i));
                                System.out.println("Apellidos: "+usuarios.getApellido(i));
                                System.out.println("Clave: "+usuarios.getClave(i));
                                System.out.println("Nivel: "+usuarios.getNivel(i));
                                System.out.println("♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦");
                                System.out.println("");
                            }
                        break;
                        
                        case 2:
                            System.out.println("");
                            System.out.println("▓▓▓▓ AGREGAR NUEVO USUARIO ▓▓▓▓");
                            System.out.print("Ingrese el correo: ");
                            String elCorreoNuevo = leer.nextLine();
                            System.out.print("Ingrese el nombre: ");
                            String elNombreNuevo = leer.nextLine();
                            System.out.print("Ingrese el apellido: ");
                            String elApellidoNuevo = leer.nextLine();
                            System.out.print("Ingrese la clave: ");
                            String laClaveNuevaNueva = leer.nextLine();
                            System.out.print("Confirme la clave: ");
                            String claveNuevaConfirmar = leer.nextLine();
                            
                            while(!claveNuevaConfirmar.equals(laClaveNuevaNueva)){
                                System.out.println("La clave no coincide...");
                                System.out.println("Confirme la clave nuevamente:");
                                claveNuevaConfirmar = leer.nextLine();
                            }

                            System.out.println("---- Seleccione el nivel de usuario ----");
                            System.out.println("1 - Usuario");
                            System.out.println("2 - Asistente");
                            System.out.println("3 - Administrador");
                            int i = 1;
                            String opcionNivel = "";
                                    
                            while( i == 1){
                                System.out.print("Ingrese el numero de la opcion deseada: ");
                                opcionNivel = leer.nextLine();
                                
                                switch(opcionNivel){
                                    case "1":
                                    case "2":
                                    case "3":
                                        usuarios.setUsuarios(elCorreoNuevo, elNombreNuevo, elApellidoNuevo, 
                                        claveNuevaConfirmar, opcionNivel);
                                        System.out.println("Datos Almacenados...");
                                        System.out.println("");
                                        i = 0;
                                    break;
                                    
                                    default:
                                        System.out.println("La opcion del nivel es incorrecta...");
                                        i = 1;
                                    break;
                                }
                            }
                        break;
                        
                        case 3:
                            System.out.println("");
                            System.out.println("▓▓▓▓ BUSCAR USUARIO ▓▓▓▓");
                            System.out.print("Ingrese el correo a buscar: ");
                            String correoBuscar = leer.nextLine();
                            
                            int indiceEncontrado = usuarios.buscarCorreo2(correoBuscar);
                            
                            if(indiceEncontrado != -1){
                                System.out.println("");
                                System.out.println("****** DATOS ENCONTRADOS ******");
                                System.out.println("Correo: "+usuarios.getCorreo(indiceEncontrado));
                                System.out.println("Nombres: "+usuarios.getNombre(indiceEncontrado));
                                System.out.println("Apellidos: "+usuarios.getApellido(indiceEncontrado));
                                System.out.println("Clave: "+usuarios.getClave(indiceEncontrado));
                                System.out.println("Nivel: "+usuarios.getNivel(indiceEncontrado));
                                System.out.println("");
                            }
                            else{
                                System.out.println("::::: NO EXISTE EL CORREO :::::");
                                System.out.println("");
                            }
                        break;
                        
                        case 4:
                            System.out.println("");
                            System.out.println("▓▓▓▓ ELIMINAR USUARIO ▓▓▓▓");
                            System.out.print("Ingrese el correo a buscar: ");
                            String correoEliminar = leer.nextLine();
                            
                            int indiceEliminar = usuarios.buscarCorreo2(correoEliminar);
                            
                            if(indiceEliminar != -1){
                                usuarios.eliminarUsuario(indiceEliminar);
                                System.out.println("::::: CORREO ELIMINADO :::::");
                            }else{
                                System.out.println("::::: NO EXISTE EL CORREO :::::");
                                System.out.println("");
                            }    
                        break;
                        
                        case 5:
                            System.out.println("");
                            System.out.println("▓▓▓▓ EDITAR USUARIO ▓▓▓▓");
                            System.out.print("Ingrese el correo del usuario que desea editar: ");
                            String usuarioEditar = leer.nextLine();
                                
                            int usuarioBuscado = usuarios.buscarCorreo2(usuarioEditar);
                            int menuEditar = 0;
                            
                            do{    
                                if(usuarioBuscado == indUsuario || usuarioBuscado == -1){
                                    System.out.println("El Usuario no puede ser editado o no existe ...");
                                    menuEditar = 0;
                                    System.out.println("");
                                    System.out.print("Ingrese el correo del usuario que desea editar: ");
                                    usuarioEditar = leer.nextLine();
                                    usuarioBuscado = usuarios.buscarCorreo2(usuarioEditar);
                                } else {
                                    System.out.println("---- MENU EDITAR USUARIO ---");
                                    System.out.println("1- Editar Correo");
                                    System.out.println("2- Editar Nombres");
                                    System.out.println("3- Editar Apellidos");
                                    System.out.println("4- Cancelar");
                                    System.out.println("");
                                    System.out.print("Ingrese el numero de la opcion deseada: ");
                                    int opcionEditar = leer.nextInt();
                                    leer.nextLine();
                                    
                                    switch(opcionEditar){
                                        case 1:
                                            System.out.println("");
                                            System.out.println("Ingrese el nuevo correo del usuario " + usuarioEditar + ": ");
                                            String nuevoCorreo = leer.nextLine();
                                            usuarios.editarCorreo(usuarioBuscado, nuevoCorreo);
                                            System.out.println("");
                                            System.out.println(" -- DATOS ACTUALIZADOS -- ");
                                            System.out.println("");
                                            menuEditar = 1;
                                        break;
                                            
                                        case 2:
                                            System.out.println("");
                                            System.out.println("Ingrese el nuevo nombre del usuario " + usuarioEditar + ": ");
                                            String nuevoNombre = leer.nextLine();
                                            usuarios.editarNombres(usuarioBuscado, nuevoNombre);
                                            System.out.println("");
                                            System.out.println(" -- DATOS ACTUALIZADOS -- ");
                                            System.out.println("");
                                            menuEditar = 1;
                                        break;
                                            
                                        case 3:
                                            System.out.println("");
                                            System.out.println("Ingrese el nuevo apellido del usuario " + usuarioEditar + ": ");
                                            String nuevoApellido = leer.nextLine();
                                            usuarios.editarApellidos(usuarioBuscado, nuevoApellido);
                                            System.out.println("");
                                            System.out.println(" -- DATOS ACTUALIZADOS -- ");
                                            System.out.println("");
                                            menuEditar = 1;
                                        break;
                                            
                                        case 4:
                                            System.out.println("");
                                            System.out.println("Cancelar: 1 = SI, 0 = NO");
                                            menuEditar = leer.nextInt();
                                            leer.nextLine();

                                            if(menuEditar == 1){
                                                menuEditar = 1;
                                            }
                                            else if(menuEditar == 0){
                                                menuEditar = 0;
                                            }
                                            break;
                                            
                                        default:
                                            System.out.println("");
                                            System.out.println("OPCION INVALIDA");
                                            menuEditar = 1;
                                        break;
                                    }//switch
                                }//else
                            }while(menuEditar != 1);   
                        break;
                        
                        case 6:
                            System.out.println("");
                            System.out.println("▓▓▓▓ CAMBIAR CONTRASEÑA ▓▓▓▓");
                            System.out.print("Ingrese el correo del usuario: ");
                            String correoEditar = leer.nextLine();
                            System.out.print("Ingrese la nueva clave: ");
                            String nuevaClave = leer.nextLine();
                            System.out.print("Confirme su nueva clave: ");
                            String confirmNuevaClave = leer.nextLine();
                            
                            int indiceCorreoEditar = usuarios.buscarCorreo2(correoEditar);
                            
                            if(indiceCorreoEditar != -1){ 
                                int j = 1;
                                
                                while(j == 1){
                                    if(confirmNuevaClave.equals(nuevaClave)){
                                        usuarios.editarClave(indiceCorreoEditar, confirmNuevaClave);
                                        System.out.println("");
                                        System.out.println("::::: CONTRASENA ACTUALIZADA :::::");
                                        System.out.println("");
                                        
                                        j = 0;
                                    }else{
                                        System.out.println("La clave no coincide...");
                                        System.out.println("Confirme la clave nuevamente:");
                                        confirmNuevaClave = leer.nextLine();
                                        j = 1;
                                    } 
                                } 
                            }else{
                                System.out.println("");
                                System.out.println("::::: NO EXISTE EL CORREO :::::");
                                System.out.println("");
                            }
                        break;
                        
                        case 7:
                            System.out.println("");
                            System.out.println("▓▓▓▓ CAMBIAR NIVEL USUARIO ▓▓▓▓");
                            System.out.print("Ingrese el correo del usuario: ");
                            String correoNivel = leer.nextLine();
                            
                            int indiceNivel = usuarios.buscarCorreo2(correoNivel);
                            
                            //Para las opciones de nivel no mostrar el nivel actual del usuario
                            if(indiceNivel != -1){
                                String nivelusuario = usuarios.getNivel(indiceNivel);                                
                                System.out.println("Nivel de usuario actual es: "+nivelusuario);//almacenar la variable el getNIvel que nos diria el nivel de usuario
                                //IF ANIDADO DE TRES NIVELES
                                int opcCambiarNivelINT = 0;
                                String opcCambiarNivel;
                                do {
                                    if(nivelusuario.equals("1")) {
                                        System.out.println("--- Seleccionar un nivel para el usuario ---");
                                        //System.out.println("1 - Usuario");
                                        System.out.println("2 - Asistente");
                                        System.out.println("3 - Administrador");
                                        System.out.println("");
                                        System.out.println("Ingrese la opcion del nivel");
                                        opcCambiarNivel = leer.nextLine();
                                        //opcCambiarNivelINT = Integer.parseInt(opcCambiarNivel);
                                        opcCambiarNivelINT = 1;
                                        usuarios.editarNivel(indiceNivel, opcCambiarNivel);
                                        System.out.println("---- NIVEL ACTUALIZADO ----");
                                    } else if (nivelusuario.equals("2")) {
                                        System.out.println("--- Seleccionar un nivel para el usuario ---");
                                        System.out.println("1 - Usuario");
                                        //System.out.println("2 - Asistente");
                                        System.out.println("3 - Administrador");
                                        System.out.println("");
                                        System.out.println("Ingrese la opcion del nivel");
                                        opcCambiarNivel = leer.nextLine();
                                        
                                        opcCambiarNivelINT = 1;
                                        usuarios.editarNivel(indiceNivel, opcCambiarNivel);
                                        //opcCambiarNivelINT = Integer.parseInt(opcCambiarNivel);
                                        System.out.println("---- NIVEL ACTUALIZADO ----");
                                        } else if (nivelusuario.equals("3")) {
                                            System.out.println("--- Seleccionar un nivel para el usuario ---");
                                            System.out.println("1 - Usuario");
                                            System.out.println("2 - Asistente");
                                            //System.out.println("3 - Administrador");
                                            System.out.println("");
                                            System.out.println("Ingrese la opcion del nivel");
                                            opcCambiarNivel = leer.nextLine();
                                            opcCambiarNivelINT = 1;
                                            usuarios.editarNivel(indiceNivel, opcCambiarNivel);
                                            //opcCambiarNivelINT = Integer.parseInt(opcCambiarNivel);
                                            System.out.println("---- NIVEL ACTUALIZADO ----");
                                        } else {
                                            System.out.println("Opción de nivel inválida");
                                            opcCambiarNivelINT = 0;
                                        }
                                    
                                } while(opcCambiarNivelINT != 1);
                                
                            }else{
                                System.out.println("--- CORREO PARA EDITAR NIVEL NO EXISTE ---");
                            }
                            
                            System.out.println("");
                        break;
                        
                        case 8:
                            System.out.println("");
                            System.out.println("▓▓▓▓ LISTADO DE USUARIOS DEL NIVEL USUARIO ▓▓▓▓");
                            
                            int cantUsuarios = usuarios.getCantCorreos();
                            
                            for(int ind =0; ind < cantUsuarios; ind++){
                                String nivelMostrar = usuarios.getNivel(ind);
                                if(nivelMostrar.equals("1")){
                                    System.out.println("Correo: "+usuarios.getCorreo(ind));
                                    System.out.println("Nombres: "+usuarios.getNombre(ind));
                                    System.out.println("Apellidos: "+usuarios.getApellido(ind));
                                    System.out.println("Clave: "+usuarios.getClave(ind));
                                    /*
                                        Mostrar el nivel del usuario correspondiente, NO el numero
                                    */
                                    System.out.println("Nivel: "+usuarios.getNivel(ind)+" - Usuario");
                                    System.out.println("♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦");
                                    System.out.println("");
                                }
                            }
                        break;
                        
                        case 9:
                            System.out.println("");
                            System.out.println("▓▓▓▓ LISTADO DE USUARIOS DEL NIVEL ASISTENTE ▓▓▓▓");
                            
                            int numUsuarios = usuarios.getCantCorreos();
                            
                            for(int ind =0; ind < numUsuarios; ind++){
                                String nivelMostrar = usuarios.getNivel(ind);
                                if(nivelMostrar.equals("2")){
                                    System.out.println("Correo: "+usuarios.getCorreo(ind));
                                    System.out.println("Nombres: "+usuarios.getNombre(ind));
                                    System.out.println("Apellidos: "+usuarios.getApellido(ind));
                                    System.out.println("Clave: "+usuarios.getClave(ind));
                                    /*
                                        Mostrar el nivel del usuario correspondiente, NO el numero
                                    */
                                    System.out.println("Nivel: "+usuarios.getNivel(ind)+" - Asistente");
                                    System.out.println("♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦");
                                    System.out.println("");
                                }
                            }
                        break;
                        
                        case 10:
                            System.out.println("");
                            System.out.println("▓▓▓▓ LISTADO DE USUARIOS DEL NIVEL ADMINISTRADOR ▓▓▓▓");
                            
                            int numeroUsuarios = usuarios.getCantCorreos();
                            
                            for(int ind =0; ind < numeroUsuarios; ind++){
                                String nivelMostrar = usuarios.getNivel(ind);
                                if(nivelMostrar.equals("3")){
                                    System.out.println("Correo: "+usuarios.getCorreo(ind));
                                    System.out.println("Nombres: "+usuarios.getNombre(ind));
                                    System.out.println("Apellidos: "+usuarios.getApellido(ind));
                                    System.out.println("Clave: "+usuarios.getClave(ind));
                                    /*
                                        Mostrar el nivel del usuario correspondiente, NO el numero
                                    */
                                    System.out.println("Nivel: "+usuarios.getNivel(ind)+" - Administrador");
                                    System.out.println("♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦");
                                    System.out.println("");
                                }
                            }
                        break;
                        
                        case 11:
                            System.out.println("");
                            System.out.println("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓");
                            System.out.println("▓▓▓   ACERCA DE...   ▓▓▓");
                            System.out.println("▓▓▓  Milagro Coreas  ▓▓▓");
                            System.out.println("▓▓▓       v1.0       ▓▓▓");
                            System.out.println("▓▓▓  25 - 0011 -2020 ▓▓▓");
                            System.out.println("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓");
                            System.out.println("");
                            
                        break;
                        
                        case 12:
                            int opcionSesion = 0;
                            
                            do{
                                System.out.println("Cerrar sesion: 1 = SI, 0 = NO");
                                opcionSesion = leer.nextInt();
                                leer.nextLine();

                                if(opcionSesion == 1){
                                    opcionesMenuPrincipal = 13;
                                    cont = 0;
                                }
                                else if(opcionSesion == 0){
                                    opcionesMenuPrincipal = 1;
                                    opcionSesion = 1;
                                }
                            }while(opcionSesion != 1);
                            
                        break;
                        
                        case 13:
                            opcionSesion = 0;
                            
                            do{
                                System.out.println("Salir del sistema: 1 = SI, 0 = NO");
                                opcionSesion = leer.nextInt();
                                leer.nextLine();

                                if(opcionSesion == 1){
                                    opcionesMenuPrincipal = 13;
                                    cont = 4;
                                }
                                else if(opcionSesion == 0){
                                    opcionesMenuPrincipal = 1;
                                    opcionSesion = 1;
                                }
                            }while(opcionSesion != 1);
                        break;
                    }

                }while(opcionesMenuPrincipal <= 11);

            }else{
                System.out.println("ERROR, usuario y/o clave no valida...");
                System.out.println("");
            }
            cont++;
            
        }while(cont <= 3);
        
        /*do{ 
            System.out.print("Ingrese el correo: ");
            String elCorreo = leer.nextLine();
            System.out.print("Ingrese el nombre: ");
            String elNombre = leer.nextLine();
            System.out.print("Ingrese el apellido: ");
            String elApellido = leer.nextLine();
            System.out.print("Ingrese la clave: ");
            String laClaveNueva = leer.nextLine();
            System.out.print("Ingrese el nivel: ");
            String elNivel = leer.nextLine();

            usuarios.setUsuarios(elCorreo, elNombre, elApellido, laClaveNueva, elNivel);

            System.out.print("Cantidad de elementos: " + usuarios.getCantCorreos());
            System.out.print("Continuar 1 = si");
            respuesta = leer.nextInt();
            leer.nextLine();
            
        }while(respuesta == 1);
        */
          
    }
 
}
